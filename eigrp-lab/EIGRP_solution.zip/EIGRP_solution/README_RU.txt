ГОТОВЫЕ ПРОЕКТЫ CISCO PACKET TRACER

Откройте EIGRP_AS10_final.pkt в Cisco Packet Tracer через File → Open.
В нём уже записаны устройства, кабели, IP-адреса ПК, настройки маршрутизаторов, EIGRP AS 10, bandwidth и passive-interface. Вставлять команды заново не требуется.

Для проверки этапов задания:
  projects/01_Direct_connectivity.pkt — адресация до EIGRP; удалённые LAN ещё не маршрутизируются.
  projects/02_EIGRP_before_bandwidth.pkt — EIGRP с исходной serial BW 1544.
  projects/EIGRP_AS10_final.pkt — итоговая BW 64/2000 и passive LAN.

Модели: Cisco 1841 + WIC-2T. LAN-интерфейс — FastEthernet0/0 вместо GigabitEthernet0/0 из исходной таблицы; это допускается заданием. На прямых PC–1841 соединениях применён crossover вместо указанного в задании straight-through для совместимости MDI-портов.

Вход в консоль: cisco. Пароль команды enable: class.
После открытия дождитесь сходимости EIGRP. Проверьте show ip interface brief, show ip eigrp neighbors, show ip route eigrp, show ip protocols и ping между всеми ПК.

ВАЖНО: .pkt сформированы программно в формате 8.2.0.0162. Структура и конфигурации проверены обратным чтением и независимым анализатором. Открытие в Cisco Packet Tracer 9.0.1 и реальные ping здесь не выполнялись. Это не утверждение об успешной работе в симуляторе.

В EIGRP_report_RU.docx / .pdf содержатся все этапы, ожидаемые результаты и ответы на 9 вопросов. Нужно заполнить ФИО/группу и вставить реальные скриншоты и результаты. topology.png — схема, не снимок приложения.

configs/ — команды для пошагового применения на 1841.
configs_1841/ — итоговые running-config и CLI-команды для восстановления.
validation.json — фактический журнал статической проверки файлов.
SOURCES.txt — происхождение шаблонов и инструментов формирования проекта.
