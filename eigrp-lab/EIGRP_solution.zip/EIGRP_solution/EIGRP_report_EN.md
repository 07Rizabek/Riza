
# Configuring Basic EIGRP for IPv4

Name: __________________________    Group: __________________________

Objective: build a three-router network, configure IPv4 and EIGRP autonomous system (AS) 10, and investigate metric-based path selection and passive interfaces.

Report status: the configurations, answers to the questions, and static validation results have been included. The user opened the final project in Cisco Packet Tracer, provided an overall topology image, and reported that everything works. The image shows six devices and green indicators at the ends of all connections. Individual CLI outputs, ping statistics, and verification screenshots have not been supplied; they must be added to Section 8 before submission. Name and group are still blank.


# Prepared Packet Tracer Projects

Open EIGRP_AS10_final.pkt using File > Open for the final network. The configurations are already included. Use projects/01_Direct_connectivity.pkt for the initial measurements and projects/02_EIGRP_before_bandwidth.pkt for EIGRP before the metric changes. The console password is cisco; the enable password is class. Allow time for EIGRP neighbors to form after opening a project. The topology image supplied by the user confirms that the final project opened in the installed application. The exact application version is not visible in that image; compatibility has not been tested separately with every version.


# 1. Topology and Addressing

![Final network schematic](topology_EN.png)

Figure 1. Original schematic of the final topology. This is not a Packet Tracer screenshot; link bandwidth values are routing metric settings in Kbps.

The prepared projects contain three Cisco 1841 routers with WIC-2T modules and three PC-PT hosts. The interfaces are Serial0/0/0, Serial0/0/1, and FastEthernet0/0. The assignment allows other router models with corresponding interface-name changes; Fa0/0 performs the role of G0/0 in the original addressing table. All PC and router settings are already stored in the projects.

Connection | End A | End B | DCE end
--- | --- | --- | ---
R1-R2 | R1 S0/0/0 | R2 S0/0/0 | R1
R2-R3 | R2 S0/0/1 | R3 S0/0/1 | R2
R1-R3 | R3 S0/0/0 | R1 S0/0/1 | R3

When rebuilding the topology, select Serial DCE and click the indicated DCE end first. Check the role with show controllers serial 0/0/0 or show controllers serial 0/0/1. Set clock rate only on the actual DCE end. Connect PC1, PC2, and PC3 FastEthernet0 to Fa0/0 on the corresponding router. The assignment specifies straight-through cables. The prepared projects use crossover cables for direct PC-to-1841 connections because both endpoints have MDI ports; this avoids relying on auto-MDIX. Addressing and the logical topology are unchanged. This cable-type deviation should be disclosed when submitting the work.

Device | Interface | IPv4 address / prefix | Default gateway
--- | --- | --- | ---
R1 | Fa0/0 | 192.168.1.1/24 | -
R1 | S0/0/0 | 10.1.1.1/30 | -
R1 | S0/0/1 | 10.3.3.1/30 | -
R2 | Fa0/0 | 192.168.2.1/24 | -
R2 | S0/0/0 | 10.1.1.2/30 | -
R2 | S0/0/1 | 10.2.2.2/30 | -
R3 | Fa0/0 | 192.168.3.1/24 | -
R3 | S0/0/0 | 10.3.3.2/30 | -
R3 | S0/0/1 | 10.2.2.1/30 | -
PC1 | FastEthernet0 | 192.168.1.3/24 | 192.168.1.1
PC2 | FastEthernet0 | 192.168.2.3/24 | 192.168.2.1
PC3 | FastEthernet0 | 192.168.3.3/24 | 192.168.3.1

The /24 subnet mask is 255.255.255.0; the /30 subnet mask is 255.255.255.252. On each PC, open Desktop > IP Configuration > Static and enter the IP address, subnet mask, and default gateway from the table. DNS is not needed for this lab.


# 2. Basic Configuration and Direct Connectivity

For a manual rebuild, decline the initial configuration dialog by entering no, press Enter, and paste the corresponding file: configs/R1_1_base.txt, configs/R2_1_base.txt, or configs/R3_1_base.txt. If the prompt is already Router#, the first enable command is unnecessary. After copy running-config startup-config, press Enter to confirm the destination filename. The passwords class and cisco are required by the classroom assignment and are not suitable for a production network.

Use show ip interface brief to verify that all three used interfaces on each router are up/up. The DCE interfaces have clock rate 64000. For down/down, check the cable and installed module. For administratively down, use no shutdown. For up/down, check the DCE clock rate and the other end of the serial link.

```text
show ip interface brief
show controllers serial 0/0/0
show controllers serial 0/0/1
show interfaces serial 0/0/0
show interfaces serial 0/0/1
```

Source | Ping checks before enabling EIGRP
--- | ---
R1 | ping 10.1.1.2; ping 10.3.3.2
R2 | ping 10.1.1.1; ping 10.2.2.1
R3 | ping 10.3.3.1; ping 10.2.2.2
PC1 / PC2 / PC3 | Ping the local default gateway: 192.168.1.1 / 192.168.2.1 / 192.168.3.1

Before enabling EIGRP, run ping 192.168.2.3 and ping 192.168.3.3 on PC1. These tests are expected to fail: the PC forwards the packet to its gateway, but R1 has no routes to the remote LANs, and the remote routers have no return route to LAN1. Connected/local routes marked C/L alone are insufficient.


# 3. Configuring EIGRP AS 10

On each router, apply configs/Rn_2_eigrp.txt, where n is the router number. Use wildcard mask 0.0.0.255 for /24 networks and 0.0.0.3 for /30 networks. The correct serial networks for R2 and R3 are derived from the actual interface addresses, as clarified in the assignment document.

R1:

```text
enable
configure terminal
router eigrp 10
 network 192.168.1.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config
```

R2:

```text
enable
configure terminal
router eigrp 10
 network 192.168.2.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.2.2.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config
```

R3:

```text
enable
configure terminal
router eigrp 10
 network 192.168.3.0 0.0.0.255
 network 10.2.2.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config
```

If a particular IOS version does not accept no auto-summary, inspect show ip protocols and verify that automatic summarization is disabled by default. Do not ignore other error messages. After adjacencies form, test ping from PC1 to PC2 and PC3. The first request may be lost while ARP resolves an address; repeat the test and assess the subsequent replies.


# 4. Verifying EIGRP Routing

```text
show ip eigrp neighbors
show ip route eigrp
show ip eigrp topology
show ip protocols
show running-config
```

Router | Expected neighbors | Remote LAN routes marked D
--- | --- | ---
R1 | 10.1.1.2 (S0/0/0); 10.3.3.2 (S0/0/1) | 192.168.2.0/24; 192.168.3.0/24
R2 | 10.1.1.1 (S0/0/0); 10.2.2.1 (S0/0/1) | 192.168.1.0/24; 192.168.3.0/24
R3 | 10.3.3.1 (S0/0/0); 10.2.2.2 (S0/0/1) | 192.168.1.0/24; 192.168.2.0/24

Each router is expected to have two EIGRP neighbors. Their display order and uptime are not fixed. The local LAN is not shown as a D route by show ip route eigrp because it is directly connected. In show ip protocols, verify EIGRP AS 10, the three network statements, and disabled automatic summarization.

A successor is the neighbor providing the current best route to a destination; that path is installed in the routing table. Feasible distance (FD) is the lowest total distance retained by DUAL since the route last changed from Active to Passive. In a stable state, it normally equals the metric of the best path. Reported distance (RD) is a neighbor's distance to the destination. A feasible successor is a backup neighbor that satisfies RD < FD; an alternate route is not automatically a feasible successor. P in the topology table means Passive: the route is stable. This is different from passive-interface.

In Simulation Mode, enable the ICMP filter and ARP if necessary. Use Add Simple PDU from PC1 to PC3, or run ping in the PC command prompt. Use Capture/Forward to follow the devices along the path. Before the bandwidth changes, with equal default serial characteristics, the expected path is PC1 -> R1 -> R3 -> PC3. This is a prediction that must be verified in the simulator.


# 5. Bandwidth and Passive LAN Interfaces

Before making changes, capture show interfaces serial 0/0/0 and show interfaces serial 0/0/1 on all routers, together with show ip route eigrp. Do not assume that the initial bandwidth is 1544 Kbps without checking; the value depends on the router model and IOS. The supplied intermediate projects serialize an initial serial bandwidth of 1544 Kbps; confirm the runtime value in the application.

After recording the initial results, apply configs/Rn_4_bandwidth_passive.txt. The final serial bandwidth settings are: R1 S0/0/0 = 2000; R1 S0/0/1 = 64; R2 S0/0/0 = 2000; R2 S0/0/1 = 2000; R3 S0/0/0 = 64; R3 S0/0/1 = 2000 Kbps. Under router eigrp 10 on each router, configure passive-interface FastEthernet0/0.

With the default K-values K1=K3=1 and K2=K4=K5=0, the classic metric is 256 x (10^7 / minimum bandwidth in Kbps + the sum of delays in tens of microseconds), using IOS integer arithmetic. A higher minimum bandwidth reduces the metric; an additional hop adds delay. The bandwidth command changes a routing metric/reference value, not the physical serial line speed. The DCE clock rate remains 64000 even when the configured bandwidth is 2000.

Route to a remote LAN | Before the change* | After the change*
--- | --- | ---
R1 -> 192.168.3.0/24 | R3: next hop 10.3.3.2 | R2: next hop 10.1.1.2
R3 -> 192.168.1.0/24 | R1: next hop 10.3.3.1 | R2: next hop 10.2.2.2
R1 -> 192.168.2.0/24 | R2: next hop 10.1.1.2 | R2: next hop 10.1.1.2
R3 -> 192.168.2.0/24 | R2: next hop 10.2.2.2 | R2: next hop 10.2.2.2

*These paths are expected with equal default serial delays, initially equal bandwidths, and default K-values. Actual routing-table outputs have not been supplied. If parameters differ, check BW, DLY, and K-values and calculate the metrics. After the changes, the path R1-R2-R3 has a minimum bandwidth of 2000 Kbps instead of 64 Kbps on the direct R1-R3 link; with default delays, the path through R2 is preferred. Routes to remote serial subnets may use different or equal-cost paths; do not automatically apply the LAN conclusions to them.

```text
show interfaces serial 0/0/0
show interfaces serial 0/0/1
show ip route
show ip route eigrp
show ip eigrp neighbors
show ip eigrp topology
show ip protocols
copy running-config startup-config
```

The Passive Interface(s) section of show ip protocols should include Fa0/0. EIGRP does not send Hello packets or form adjacencies on this interface, but the LAN remains advertised over the serial interfaces. Each router should retain its two serial neighbors, and PC-to-PC ping should still work. Do not make the serial interfaces passive.


# 6. Final Connectivity and Failure Recovery Checks

Source | Ping destinations
--- | ---
PC1 | 192.168.2.3 and 192.168.3.3
PC2 | 192.168.1.3 and 192.168.3.3
PC3 | 192.168.1.3 and 192.168.2.3

Test all six directions, repeat each test after ARP completes, and record the actual numbers of packets sent and received. On PC1, run tracert 192.168.3.3. After the bandwidth changes, the expected route passes through R1, R2, and R3. The displayed interface addresses may depend on the source interface used for the ICMP replies.

Before testing a failure, save the working configuration. Temporarily shut down S0/0/1 on R1 using the commands below. With the final bandwidth settings, this direct link is normally no longer on the preferred path between LAN1 and LAN3. The path through R2 remains available. With the initial metrics, EIGRP must replace the direct path with R1-R2-R3. Brief packet loss may occur during convergence. If no feasible successor exists, DUAL uses a query/reply process before selecting a new route.

```text
enable
configure terminal
interface Serial0/0/1
 shutdown
end
show ip eigrp neighbors
show ip route eigrp
```

Repeat the PC1-to-PC3 ping, then restore the serial link and save the final state:

```text
configure terminal
interface Serial0/0/1
 no shutdown
end
show ip eigrp neighbors
copy running-config startup-config
```

Wait until each router again has two neighbors. Save the project using File > Save As > EIGRP_AS10_final.pkt. The configs/Rn_FINAL.txt files can recreate the final settings from scratch, but they do not replace the staged lab procedure or the initial measurements.


# 7. Answers to the Laboratory Questions

1. What does EIGRP stand for, and what is its purpose?

EIGRP stands for Enhanced Interior Gateway Routing Protocol. It dynamically exchanges routes within a routing domain, selects paths according to a metric, and uses the Diffusing Update Algorithm (DUAL) for loop-free routing and route recalculation.

2. Why must all three routers use the same EIGRP autonomous system number in this lab?

All routers must belong to the same EIGRP process, AS 10, to form adjacencies and exchange routes in this lab. Different AS numbers do not form EIGRP adjacencies with each other without additional design and configuration. K-values, addressing, and other required parameters must also be compatible.

3. What is the difference between a subnet mask and a wildcard mask?

In a subnet mask, a 1 identifies the network portion and a 0 identifies the host portion. In a wildcard mask, a 0 means that the bit must match and a 1 means that the bit is ignored. For a conventional contiguous subnet mask, the wildcard mask is its bitwise inverse: /24 uses 0.0.0.255 and /30 uses 0.0.0.3. The EIGRP network command selects local interfaces by their IP addresses; it does not create an arbitrary route to a remote network.

4. How does EIGRP discover its neighboring routers?

EIGRP for IPv4 sends Hello packets using IP protocol 88, normally to multicast address 224.0.0.10. Routers with compatible parameters on a common directly connected subnet form an adjacency. The hold timer tracks neighbor availability.

5. What does the letter D mean in the Cisco IPv4 routing table?

D identifies a route learned through EIGRP; the notation is associated with DUAL. D EX identifies an external EIGRP route. The default administrative distance for an internal EIGRP route is 90.

6. How does the bandwidth setting influence EIGRP path selection?

With default K-values, EIGRP uses the minimum bandwidth along the path and the cumulative delay. Increasing the minimum bandwidth reduces the bandwidth component of the metric. After the direct R1-R3 link is configured with bandwidth 64, the path over two links configured with bandwidth 2000 becomes preferable when standard interface delays apply.

7. What is a passive interface, and why should it be used on a LAN-facing router interface?

A passive interface does not send EIGRP Hello packets or establish EIGRP adjacencies. Its connected LAN continues to be advertised to other neighbors if the interface is selected by a network statement. This prevents unnecessary Hello traffic and unwanted adjacencies with devices on a user LAN.

8. What happens to communication if the R1-R3 serial connection fails?

Connectivity among the three LANs is preserved through R1-R2-R3 if the two remaining serial links and EIGRP are operational. The adjacency on the failed link disappears. With the final metrics, the path through R2 is normally already selected. With the initial metrics, routing must converge onto the alternate path.

9. How would you verify that all three PCs can communicate successfully?

Check each PC's IP address, subnet mask, and default gateway; ping each local gateway, then test all six PC-to-PC directions. Use tracert, inspect the routing tables, verify two EIGRP neighbors per router, and follow ICMP in Simulation Mode. A successful ping to a local gateway alone does not prove communication between different LANs.


# 8. Evidence and Actual Results

Completed in the preparation environment: the assignment document was reviewed and three encrypted .pkt containers were created, each with six devices and six connections. The configurations were checked statically against the addressing table and DCE roles. Checks covered unique MAC addresses, running/startup configuration records, and container decoding after encoding. An independent analyzer also checked the serialized structure and device state. Cisco IOS simulation was not run in the preparation environment.

The final project did open in the user's Packet Tracer application. The topology image supplied in the conversation shows R1/R2/R3, PC1/PC2/PC3, and green indicators for all six connections. The user reported that everything works. That general confirmation does not document the outputs of individual commands, EIGRP neighbor counts, or the number of successful ping replies. The supplied topology image is not available as a separate local image file for embedding. Figure 1 is an original schematic and must not be substituted for a real Packet Tracer screenshot.

No. | Required screenshot | What it should demonstrate
--- | --- | ---
01 | Complete topology | All 3 routers and 3 PCs, labels, interfaces, and active links
02 | show ip interface brief | Each router's addresses and up/up interface states
03 | PC addressing and gateway ping | IP Configuration on every PC and successful local gateway pings
04 | EIGRP configuration | show running-config on R1/R2/R3, including AS and network statements
05 | PC-to-PC ping after EIGRP | PC1 to PC2 and PC1 to PC3
06 | EIGRP neighbors | Two neighbors on each router
07 | EIGRP routes | Remote LANs marked D on all routers
08 | Topology and protocol verification | show ip eigrp topology and show ip protocols
09 | Simulation Mode / ICMP | The actual packet path between different LANs
10 | Serial bandwidth before and after | show interfaces: BW and DLY at both ends of every serial link
11 | Routes after the bandwidth changes | Selected next hops compared with the initial routing tables
12 | Passive interfaces and final connectivity | show ip protocols, neighbors, and all six PC-to-PC ping directions

More than one image may be used for a numbered requirement, for example 06_R1.png, 06_R2.png, and 06_R3.png. Save actual screenshots in screenshots/ and insert them into the Word report with a caption identifying the device and stage. The topology image supplied in the conversation must be provided as a separate image file before it can be embedded. CLI and ping screenshots have not yet been supplied. Complete the name and group fields before submission.

Check | Expected result | Documented result
--- | --- | ---
Project opening | All 6 devices and their connections are visible | Confirmed by the user's image in the conversation
Connection indicators | Green indicators at the ends of all links | The supplied image shows green indicators
General operation | The configured network operates | The user reported that everything works; individual tests were not specified
Before EIGRP | Local pings succeed; remote LANs are unreachable | Individual test outputs have not been supplied
After EIGRP | 2 neighbors per router, D routes to remote LANs, successful ping | CLI and ping outputs have not been supplied
After bandwidth changes | LAN1-to-LAN3 path via R2 with standard delays | Before/after routing tables have not been supplied
After passive Fa0/0 | Serial neighbors remain and the PCs remain reachable | show ip protocols output has not been supplied
R1-R3 failure and recovery | Traffic uses R2; adjacencies recover after link restoration | A separate failure-test result has not been supplied


# 9. Conclusion

An EIGRP AS 10 configuration has been prepared for three IPv4 LANs and three serial networks. The metric analysis predicts that traffic between LAN1 and LAN3 will use R2 after the direct R1-R3 link's logical bandwidth is reduced, and that making the LAN interfaces passive will preserve routing. The final .pkt project and two intermediate projects were created programmatically. The user's topology image confirms that the project opens and shows active link indicators; general operation was confirmed in the user's message. To finish the report, add actual EIGRP and ping screenshots and the routing comparison before and after the metric changes. Until those evidence items are added, the report does not fully satisfy the assignment's submission requirements.


# Appendix. Complete Final CLI Configurations

These are the complete commands for a manual rebuild on the Cisco 1841 topology. They preserve the assignment's addressing and include EIGRP, final bandwidth settings, passive LAN interfaces, and configuration saving. Press Enter to confirm the destination filename after copy running-config startup-config. Do not reapply the final configurations before capturing the initial-stage measurements.


## R1

```text
enable
configure terminal
hostname R1
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.1.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.1.1.1 255.255.255.252
 clock rate 64000
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.3.3.1 255.255.255.252
 no shutdown
 exit
router eigrp 10
 network 192.168.1.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 2000
 exit
interface Serial0/0/1
 bandwidth 64
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config
```


## R2

```text
enable
configure terminal
hostname R2
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.2.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.1.1.2 255.255.255.252
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.2.2.2 255.255.255.252
 clock rate 64000
 no shutdown
 exit
router eigrp 10
 network 192.168.2.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.2.2.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 2000
 exit
interface Serial0/0/1
 bandwidth 2000
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config
```


## R3

```text
enable
configure terminal
hostname R3
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.3.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.3.3.2 255.255.255.252
 clock rate 64000
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.2.2.1 255.255.255.252
 no shutdown
 exit
router eigrp 10
 network 192.168.3.0 0.0.0.255
 network 10.2.2.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 64
 exit
interface Serial0/0/1
 bandwidth 2000
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config
```

