
# Настройка базового EIGRP для IPv4

ФИО: __________________________    Группа: __________________________

Цель: построить сеть из трёх маршрутизаторов, настроить IPv4 и EIGRP AS 10, исследовать выбор маршрута по метрике и пассивные интерфейсы.

Статус: созданы три проекта .pkt, конфигурации и теоретическое решение. Проекты сформированы программно в формате Packet Tracer 8.2.0.0162; структура проверена обратным чтением. Открытие в Cisco Packet Tracer 9.0.1, реальные выводы IOS, ping и скриншоты здесь не проверены. Перед сдачей нужно подтвердить работу в приложении и приложить реальные результаты.


# Готовые файлы Packet Tracer

Для итоговой сети открыть EIGRP_AS10_final.pkt через File → Open. Конфигурации уже внесены. Для исходных измерений использовать projects/01_Direct_connectivity.pkt, для EIGRP до изменения метрик — projects/02_EIGRP_before_bandwidth.pkt. На консолях пароль cisco, для enable — class. При открытии дать сети время на установление соседств. Если версия приложения отклоняет формат, сохранить сообщение об ошибке: совместимость с 9.0.1 здесь не проверена.


# 1. Топология и адресация

В готовых проектах установлены три Cisco 1841 с модулями WIC-2T и три PC-PT. Использованы Serial0/0/0, Serial0/0/1 и FastEthernet0/0. Задание допускает другие модели с адаптацией имён интерфейсов; здесь Fa0/0 выполняет роль G0/0 из исходной таблицы. Настройки ПК и всех маршрутизаторов уже записаны в проекты.

Соединение | Конец A | Конец B | DCE
R1–R2 | R1 S0/0/0 | R2 S0/0/0 | R1
R2–R3 | R2 S0/0/1 | R3 S0/0/1 | R2
R1–R3 | R3 S0/0/0 | R1 S0/0/1 | R3

Выбрать Serial DCE и первым нажать указанный DCE-конец. Проверить роль командой show controllers serial 0/0/0 или show controllers serial 0/0/1. Clock rate задаётся только на фактическом DCE-конце. Подключить PC1/PC2/PC3 FastEthernet0 к Fa0/0 соответствующего маршрутизатора. В задании указан straight-through. В проектах для прямого PC–1841 соединения использован crossover: оба порта относятся к MDI, поэтому не требуется полагаться на auto-MDIX. Адресация и логическая топология сохранены; это отклонение от указанного типа кабеля следует учитывать при сдаче.

Устройство | Интерфейс | IPv4 / префикс | Шлюз
R1 | Fa0/0 | 192.168.1.1/24 | —
R1 | S0/0/0 | 10.1.1.1/30 | —
R1 | S0/0/1 | 10.3.3.1/30 | —
R2 | Fa0/0 | 192.168.2.1/24 | —
R2 | S0/0/0 | 10.1.1.2/30 | —
R2 | S0/0/1 | 10.2.2.2/30 | —
R3 | Fa0/0 | 192.168.3.1/24 | —
R3 | S0/0/0 | 10.3.3.2/30 | —
R3 | S0/0/1 | 10.2.2.1/30 | —
PC1 | FastEthernet0 | 192.168.1.3/24 | 192.168.1.1
PC2 | FastEthernet0 | 192.168.2.3/24 | 192.168.2.1
PC3 | FastEthernet0 | 192.168.3.3/24 | 192.168.3.1

Маска /24: 255.255.255.0; /30: 255.255.255.252. На каждом ПК открыть Desktop → IP Configuration → Static и указать IP, маску и шлюз из таблицы. DNS для этой работы не требуется.


# 2. Базовая настройка и прямая связность

В CLI маршрутизатора отказаться от initial configuration dialog (no), нажать Enter и вставить соответствующий файл configs/R1_1_base.txt, R2_1_base.txt или R3_1_base.txt. Если уже открыт режим Router#, первая команда enable избыточна. После copy running-config startup-config подтвердить имя destination клавишей Enter. Пароли class и cisco заданы по учебному заданию и не подходят для реальной сети.

Проверить show ip interface brief: все три используемых интерфейса должны быть up/up. На DCE настроено clock rate 64000. При down/down проверить кабель и модуль; при administratively down — no shutdown; при up/down — DCE clock rate и второй конец линии.

```text
show ip interface brief
show controllers serial 0/0/0
show controllers serial 0/0/1
show interfaces serial 0/0/0
show interfaces serial 0/0/1
```

Откуда | Проверки ping до включения EIGRP
R1 | ping 10.1.1.2; ping 10.3.3.2
R2 | ping 10.1.1.1; ping 10.2.2.1
R3 | ping 10.3.3.1; ping 10.2.2.2
PC1 / PC2 / PC3 | ping своего шлюза: 192.168.1.1 / 192.168.2.1 / 192.168.3.1

На PC1 до включения EIGRP выполнить ping 192.168.2.3 и ping 192.168.3.3. Ожидается отсутствие связности: ПК отправляет пакет шлюзу, но у R1 нет маршрутов в удалённые LAN, а у удалённых маршрутизаторов нет обратного маршрута в LAN1. Подключённых маршрутов C/L недостаточно.


# 3. Настройка EIGRP AS 10

На каждом маршрутизаторе применить файл configs/Rn_2_eigrp.txt, где n — номер маршрутизатора. Для /24 использовать wildcard 0.0.0.255, для /30 — 0.0.0.3. Правильные сети R2 и R3 определены по адресам интерфейсов, как уточнено в документе задания.

R1:

```text
enable
configure terminal
router eigrp 10
 network 192.168.1.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config

```

R2:

```text
enable
configure terminal
router eigrp 10
 network 192.168.2.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.2.2.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config

```

R3:

```text
enable
configure terminal
router eigrp 10
 network 192.168.3.0 0.0.0.255
 network 10.2.2.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
end
copy running-config startup-config

```

Если конкретный IOS не поддерживает no auto-summary, проверить show ip protocols: автоматическая суммаризация должна быть выключена по умолчанию. Не игнорировать другие сообщения об ошибках. После установления соседства проверить ping с PC1 к PC2 и PC3. Первый запрос может потеряться при ARP; повторить и оценить последующие ответы.


# 4. Проверка маршрутизации

```text
show ip eigrp neighbors
show ip route eigrp
show ip eigrp topology
show ip protocols
show running-config
```

Маршрутизатор | Ожидаемые соседи | Удалённые LAN с кодом D
R1 | 10.1.1.2 (S0/0/0); 10.3.3.2 (S0/0/1) | 192.168.2.0/24; 192.168.3.0/24
R2 | 10.1.1.1 (S0/0/0); 10.2.2.1 (S0/0/1) | 192.168.1.0/24; 192.168.3.0/24
R3 | 10.3.3.1 (S0/0/0); 10.2.2.2 (S0/0/1) | 192.168.1.0/24; 192.168.2.0/24

Ожидается по два соседа на маршрутизатор. Их порядок и uptime не фиксированы. В show ip route eigrp локальная LAN не отображается как D, поскольку она directly connected. В show ip protocols проверить EIGRP AS 10, три network statement и отсутствие auto-summary.

Successor — сосед, обеспечивающий лучший текущий маршрут к сети; через него маршрут устанавливается в таблицу маршрутизации. Feasible distance (FD) — сохранённая DUAL наименьшая суммарная дистанция до назначения с последнего перехода маршрута из Active в Passive. В устойчивом состоянии она обычно совпадает с метрикой лучшего пути. Reported distance (RD) — дистанция соседа до назначения. Feasible successor — запасной сосед, удовлетворяющий условию RD < FD; любой альтернативный путь не обязательно является feasible successor. Буква P в таблице топологии означает Passive — маршрут стабилен; это не passive-interface.

В Simulation Mode оставить фильтры ICMP и при необходимости ARP; использовать Add Simple PDU от PC1 к PC3 или ping из командной строки ПК. Через Capture/Forward проследить устройства по пути. До изменения bandwidth при одинаковых стандартных характеристиках serial ожидается PC1 → R1 → R3 → PC3. Это прогноз, который нужно подтвердить в симуляторе.


# 5. Bandwidth и пассивные LAN-интерфейсы

До изменения сохранить вывод show interfaces serial 0/0/0 и show interfaces serial 0/0/1 на всех маршрутизаторах, а также show ip route eigrp. Не считать исходную BW равной 1544 Кбит/с без проверки: значение зависит от модели и IOS.

После записи исходных результатов применить configs/Rn_4_bandwidth_passive.txt. Настройки: R1 S0/0/0 = 2000; R1 S0/0/1 = 64; R2 S0/0/0 = 2000; R2 S0/0/1 = 2000; R3 S0/0/0 = 64; R3 S0/0/1 = 2000 Кбит/с. В EIGRP на каждом маршрутизаторе настроить passive-interface FastEthernet0/0.

При стандартных K-значениях K1=K3=1 и K2=K4=K5=0 классическая метрика равна 256 × (10^7 / минимальная BW в Кбит/с + сумма задержек в десятках микросекунд), с целочисленным расчётом IOS. Более высокая минимальная BW уменьшает метрику; дополнительный переход добавляет задержку. Команда bandwidth не меняет физическую скорость линии. На DCE остаётся clock rate 64000, даже если логическая BW задана 2000.

Маршрут к удалённой LAN | До изменения* | После изменения*
R1 → 192.168.3.0/24 | R3: next hop 10.3.3.2 | R2: next hop 10.1.1.2
R3 → 192.168.1.0/24 | R1: next hop 10.3.3.1 | R2: next hop 10.2.2.2
R1 → 192.168.2.0/24 | R2: next hop 10.1.1.2 | R2: next hop 10.1.1.2
R3 → 192.168.2.0/24 | R2: next hop 10.2.2.2 | R2: next hop 10.2.2.2

*Ожидаемые пути при равных стандартных serial delay, исходно одинаковой BW и стандартных K-значениях. Реальные таблицы не получены. При других параметрах проверить BW, DLY, K-значения и вычислить метрики. После изменений путь R1–R2–R3 имеет минимальную BW 2000 вместо 64 на прямом R1–R3; при стандартных задержках он предпочтительнее. Для удалённых serial-подсетей возможны другие или равностоимостные пути — не переносить на них выводы о LAN автоматически.

```text
show interfaces serial 0/0/0
show interfaces serial 0/0/1
show ip route
show ip route eigrp
show ip eigrp neighbors
show ip eigrp topology
show ip protocols
copy running-config startup-config
```

В show ip protocols раздел Passive Interface(s) должен включать Fa0/0. EIGRP не отправляет Hello и не создаёт соседства на этом интерфейсе, но LAN остаётся объявленной через serial-интерфейсы. На serial-портах остаются по два соседа, PC-to-PC ping должен работать. Не делать serial-интерфейсы пассивными.


# 6. Итоговые проверки и отказоустойчивость

Источник | Назначения ping
PC1 | 192.168.2.3 и 192.168.3.3
PC2 | 192.168.1.3 и 192.168.3.3
PC3 | 192.168.1.3 и 192.168.2.3

Выполнить все шесть направлений, повторить каждый тест после ARP и записать фактическое число отправленных/полученных пакетов. На PC1 выполнить tracert 192.168.3.3: после изменения ожидается путь через R1, R2, R3. Порядок выводимых адресов может зависеть от исходного интерфейса ICMP-ответа.

Для испытания отказа сначала сохранить исправную конфигурацию. На R1 временно выключить S0/0/1 следующими командами. После изменения bandwidth этот линк обычно уже не является лучшим путём между LAN1 и LAN3. Резервный путь через R2 сохраняется; при исходных метриках EIGRP перестроит прямой путь на R1–R2–R3. Возможны кратковременные потери при сходимости. Если feasible successor отсутствует, DUAL выполняет query/reply до выбора нового пути.

```text
enable
configure terminal
interface Serial0/0/1
 shutdown
end
show ip eigrp neighbors
show ip route eigrp
```

Повторить PC1 → PC3 ping, затем обязательно восстановить линию и сохранить итоговое состояние:

```text
configure terminal
interface Serial0/0/1
 no shutdown
end
show ip eigrp neighbors
copy running-config startup-config
```

Дождаться восстановления двух соседей на каждом маршрутизаторе. Сохранить File → Save As → EIGRP_AS10_final.pkt. Файлы configs/Rn_FINAL.txt позволяют получить конечные настройки с нуля, но не заменяют этапы лабораторной работы и исходные измерения.


# 7. Ответы на вопросы

1. Что означает EIGRP и для чего он нужен?

Enhanced Interior Gateway Routing Protocol — усовершенствованный протокол маршрутизации внутренних шлюзов. Он динамически обменивается маршрутами внутри домена, выбирает пути по метрике и использует DUAL для обеспечения отсутствия петель и пересчёта маршрутов.

2. Почему нужен одинаковый AS?

Маршрутизаторы должны принадлежать одному EIGRP-процессу AS 10, чтобы создать соседство и обмениваться маршрутами в этой работе. Разные AS без дополнительной конфигурации не образуют соседство. Также должны быть совместимы K-значения, адресация и другие параметры.

3. Чем отличаются subnet mask и wildcard mask?

Маска подсети: 1 — часть сети, 0 — часть узла. В wildcard: 0 — бит должен совпасть, 1 — бит игнорируется. Для обычной непрерывной маски wildcard является побитовой инверсией: /24 → 0.0.0.255; /30 → 0.0.0.3. Команда network выбирает локальные интерфейсы по IP, а не задаёт произвольный удалённый маршрут.

4. Как обнаруживаются соседи?

EIGRP для IPv4 отправляет Hello по IP protocol 88, обычно на multicast 224.0.0.10. При совместимых параметрах и общей непосредственно подключённой подсети формируется соседство; Hold Timer отслеживает доступность соседа.

5. Что означает D?

D обозначает маршрут, изученный через EIGRP; обозначение связано с алгоритмом DUAL. D EX — внешний EIGRP-маршрут. Для внутренних EIGRP-маршрутов административная дистанция по умолчанию 90.

6. Как bandwidth влияет на выбор пути?

При стандартных K-значениях EIGRP использует минимальную BW вдоль пути и сумму задержек. Увеличение минимальной BW уменьшает компонент метрики. После задания прямому R1–R3 BW 64 путь через две линии BW 2000 при стандартных задержках становится предпочтительнее.

7. Что такое passive interface и зачем он в LAN?

Пассивный интерфейс не отправляет EIGRP Hello и не образует EIGRP-соседства. Подключённая LAN продолжает объявляться другим соседям, если интерфейс охвачен network. Это исключает ненужные Hello и соседства с устройствами пользовательской LAN.

8. Что произойдёт при отказе R1–R3?

Связность между тремя LAN сохранится через R1–R2–R3, если обе оставшиеся линии исправны и EIGRP работает. Соседство на отказавшей линии исчезнет. При итоговых метриках путь через R2 уже обычно выбран; при исходных метриках потребуется сходимость.

9. Как проверить связь всех ПК?

Проверить IP/маску/шлюз, ping каждого локального шлюза, затем шесть направлений ping между тремя ПК. Проверить tracert, таблицы маршрутизации и по два EIGRP-соседа, а в Simulation Mode проследить ICMP. Успешный ping только шлюза не доказывает межсетевую связность.


# 8. Доказательства и фактические результаты

Фактически в среде подготовки: документ задания прочитан, созданы три зашифрованных контейнера .pkt с шестью устройствами и шестью соединениями каждый, конфигурации сформированы и статически проверены на соответствие адресации и ролям DCE. Проверены уникальность MAC-адресов, записи running/startup-config и обратное чтение контейнеров. Проверки Cisco IOS и Packet Tracer не выполнялись. В таблицу ниже нужно добавить результаты собственного запуска; схемой topology.png нельзя заменять скриншот из Packet Tracer.

№ | Скриншот | Что подтвердить
01 | Полная топология | Все 3 маршрутизатора и 3 ПК, подписи, интерфейсы и активные линии
02 | show ip interface brief | Вывод каждого маршрутизатора: адреса и up/up
03 | Адресация ПК и ping шлюза | IP Configuration каждого ПК и успешные локальные ping
04 | Конфигурация EIGRP | На R1/R2/R3 show running-config с AS и network
05 | PC-to-PC после EIGRP | PC1 → PC2 и PC1 → PC3
06 | EIGRP neighbors | По два соседа на каждом маршрутизаторе
07 | EIGRP routes | Удалённые LAN с кодом D на всех маршрутизаторах
08 | Topology и protocols | show ip eigrp topology и show ip protocols
09 | Simulation / ICMP | Фактический путь пакета между LAN
10 | Serial BW до и после | show interfaces: BW и DLY обоих концов всех линий
11 | Таблицы после изменения BW | Выбранные next hop и сравнение с исходными таблицами
12 | Passive и финальная связность | show ip protocols, neighbors и все шесть направлений ping

Для каждого номера допускается несколько скриншотов: например, 06_R1.png, 06_R2.png, 06_R3.png. Сохранять их в screenshots/ и вставить в этот Word-отчёт с подписью, устройством и этапом. ФИО и группу заполнить самостоятельно. Не подменять ожидаемые результаты выводами, которых не было.

Этап | Ожидаемый результат | Факт
До EIGRP | Локальные ping проходят; удалённые LAN недоступны | Не выполнено
После EIGRP | 2 соседа/маршрутизатор; удалённые LAN с D; ping проходит | Не выполнено
После bandwidth | Путь LAN1↔LAN3 через R2 при стандартных delay | Не выполнено
После passive Fa0/0 | Соседи serial сохраняются, все ПК доступны | Не выполнено
Отказ и восстановление R1–R3 | Связь через R2; затем восстановление двух соседей | Не выполнено


# 9. Вывод

Подготовлена конфигурация EIGRP AS 10 для трёх IPv4 LAN и трёх serial-сетей. Теоретический анализ показывает выбор пути через R2 после снижения логической bandwidth прямой линии R1–R3 и сохранение маршрутизации при пассивных LAN-интерфейсах. Итоговый проект .pkt и два промежуточных проекта подготовлены программно. Практическое подтверждение их работы и реальные скриншоты требуют запуска в Cisco Packet Tracer; до этого лабораторную работу нельзя считать полностью проверенной.


# Приложение. Полные итоговые конфигурации


# R1

```text
enable
configure terminal
hostname R1
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.1.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.1.1.1 255.255.255.252
 clock rate 64000
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.3.3.1 255.255.255.252
 no shutdown
 exit
router eigrp 10
 network 192.168.1.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 2000
 exit
interface Serial0/0/1
 bandwidth 64
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config

```


# R2

```text
enable
configure terminal
hostname R2
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.2.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.1.1.2 255.255.255.252
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.2.2.2 255.255.255.252
 clock rate 64000
 no shutdown
 exit
router eigrp 10
 network 192.168.2.0 0.0.0.255
 network 10.1.1.0 0.0.0.3
 network 10.2.2.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 2000
 exit
interface Serial0/0/1
 bandwidth 2000
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config

```


# R3

```text
enable
configure terminal
hostname R3
no ip domain-lookup
enable secret class
banner motd #WARNING: Authorized access only!#
line console 0
 password cisco
 login
 logging synchronous
 exit
line vty 0 4
 password cisco
 login
 logging synchronous
 exit
interface FastEthernet0/0
 ip address 192.168.3.1 255.255.255.0
 no shutdown
 exit
interface Serial0/0/0
 ip address 10.3.3.2 255.255.255.252
 clock rate 64000
 no shutdown
 exit
interface Serial0/0/1
 ip address 10.2.2.1 255.255.255.252
 no shutdown
 exit
router eigrp 10
 network 192.168.3.0 0.0.0.255
 network 10.2.2.0 0.0.0.3
 network 10.3.3.0 0.0.0.3
 no auto-summary
 exit
interface Serial0/0/0
 bandwidth 64
 exit
interface Serial0/0/1
 bandwidth 2000
 exit
router eigrp 10
 passive-interface FastEthernet0/0
 exit
end
copy running-config startup-config

```
